# first exercise in "Sentencias condicionales e oterativas" challenge
# define vaiables
    #inMaCo: índice de masa corporal
    #weight: peso en kilogramos de la persona que desea calcular su inMaCo
    #height: altura en metros de la persona que desea calcular su inMaCo
#fórmula para el cálculo de inMaCo
    #inMaCo=(weight/height**2) o
    ##### if the before function don't work  ---inMaCo=(weight/height*height)---

#Ingreso de datos
weight= int(input("Escriba su peso en kilogramos y separado por punto: "))
height= int(input("Escrba su altura en centímetros: "))
inMaCo= round((weight)/(pow((height*0.01),2)),2)
#inMaCo= (weight/(height*height))
print ("-----**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-----")
print ("Sus datos".upper())
print(f"Su peso es: {weight} kg")
print(f"Su altura es: {height} cm")
print ("-----**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-----")
print ("Su resultado".upper())
print(f"Su Índice de Masa Corporal o IMC es: {inMaCo} kg/m^2")
print ("-----**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-----")
print ("Observación".upper())

# if weight > 0 and height > 0:
#     print ("Sus valores son válidos")
# else:
#     Print("Ingrese valores válidos")
#     exit()

while inMaCo > 0 and inMaCo > 0:
    if inMaCo < 18.5:
        print (f"Según los cálculos su IMC es {inMaCo}, el cual es menor a 18.5, según la OMS usted está *Bajo Peso*")
    elif inMaCo < 25:
        print (f"Según los cálculos su IMC es {inMaCo}, el cual es menor a 25, según la OMS usted está *con Peso Adecuado*")
    elif inMaCo < 30:
        print (f"Según los cálculos su IMC es {inMaCo}, el cual es menor a 30, según la OMS usted está *Sobrepeso*")
    elif inMaCo < 35:
        print (f"Según los cálculos su IMC es {inMaCo}, el cual es menor a 35, según la OMS usted está *con Obesidad grado I*")
    elif inMaCo < 40:
        print (f"Según los cálculos su IMC es {inMaCo}, el cual es menor a 40, según la OMS usted está *con Obesidad grado II*")
    else:
        print (f"Según los cálculos su IMC es {inMaCo}, el cual es mayor o igual a 40, según la OMS usted está *con Obesidad grado III*")
    print("Vuelva a ingresar valores")
    break










