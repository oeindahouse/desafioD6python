import random

#jugador, opcion de quien ingresa el valor entre piedra papel tijera
#computador, opcion random del computador

print ("-----**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-----")
print ("Valores válidos: * piedra * papel * tijera * ")

def cachipun(jugador, computador):
    jugador: str(input("Elija su opcion: "))
    print(f"Jugador elige opción: {jugador}")
    print(f"Computador elige random: {computador}")


    if jugador == computador:
        return "Empate"
    elif (
        (jugador == 'piedra' and computador == 'tijera') or
        (jugador == 'papel' and computador == 'piedra') or
        (jugador == 'tijera' and computador == 'papel')
    ):
        return "¡Jugador gana!"
    else:
        return "¡Computador gana!"

if __name__ == "__main__":
    mano = ['piedra', 'papel', 'tijera']
    
    # jugador input his preference
    jugador = input("Elige entre los valores indicados: ").lower()

    # computador random.choice selection
    computador = random.choice(mano)

    if jugador in mano:
        resultado = cachipun(jugador, computador)
        print(resultado)
    else:
        print("Opción inválida. Elige piedra, papel o tijera.")
